package Cashkro;

import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import Base.baseClass;
import common.Logs;
import common.forgetPwd;
import common.login;
import common.logo;

public class loginScript extends baseClass {
	

	@Test(priority=1)
	public void loginScript()
	{
		logo l = new logo(driver,pr);
		l.VerifyAndClickOnLogo();
		Logs.log_generate("Logo is displaying on home page and is clickable too", "loginScript");
		login log_in = new login(driver, pr);
		
		log_in.verify_Login(pr.getProperty("PassLoginUserName"), pr.getProperty("PassLoginPassword"));
		driver.findElementByXPath(pr.getProperty("myaccount")).isDisplayed();
		Logs.log_generate("user is signed in into the account", "loginScript");
		
	}
	
	@Test (priority = 2)
	public void forgetPwdSript() throws InterruptedException
	{
		forgetPwd fp = new forgetPwd(driver, pr);
		fp.verify_forgetPwd("lokeshsharma@mailgutter.com");
		
		driver.get("https://mailgutter.com/");
		driver.findElementByXPath("//input[@id=\"keyword\"]").sendKeys(pr.getProperty("ForgetLoginUsername"));
		driver.findElementByXPath("//input[@value=\"Check Inbox\"]").click();
		if(driver.findElementByXPath(pr.getProperty("noEmail")).isDisplayed()==true) {
			System.out.println("Email not gets triggered to the user");
			
		}
		
	}
}
