package common;

import java.util.Properties;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class forgetPwd {
	ChromeDriver driver;
	Properties pr;

	public forgetPwd(ChromeDriver driver, Properties pr) {
		this.driver = driver;
		this.pr = pr;
	}
	
	public void verify_forgetPwd(String useremail) throws InterruptedException
	{
		driver.findElementByXPath(pr.getProperty("signin")).click();
		driver.findElementByXPath(pr.getProperty("forgetpassword")).click();
		Thread.sleep(3000);
		WebElement fr = driver.findElementByXPath(pr.getProperty("iframe"));
		driver.switchTo().frame(fr);
		driver.findElementByXPath(pr.getProperty("forgetpwd_email")).sendKeys(useremail);
		driver.findElementByXPath(pr.getProperty("resetpwd_btn")).click();
		driver.findElementByXPath(pr.getProperty("pwd_sent")).isDisplayed();
	}
}
