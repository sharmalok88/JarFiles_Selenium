package common;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;

public class login {
	ChromeDriver driver;
	Properties pr;

	public login(ChromeDriver driver, Properties pr) {
		this.driver = driver;
		this.pr = pr;
	}

	public void verify_Login(String useremail, String pwd) 
	{
		try {
		driver.findElementByXPath(pr.getProperty("signin")).click();
		driver.findElementByXPath(pr.getProperty("email")).sendKeys(useremail);
		driver.findElementByXPath(pr.getProperty("password")).sendKeys(pwd);
		driver.findElementByXPath(pr.getProperty("signin_btn")).click();
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("Verify login method failed");
		}
	}
	
}
