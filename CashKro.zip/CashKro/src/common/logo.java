package common;

import static org.testng.Assert.assertEquals;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;


public class logo {
	ChromeDriver driver;
	Properties pr;

	public  logo(ChromeDriver driver, Properties pr) {
		this.driver = driver;
		this.pr = pr;
	}

	public void VerifyAndClickOnLogo() {
		driver.findElementByXPath(pr.getProperty("logo")).isDisplayed();
		driver.findElementByXPath(pr.getProperty("logo")).click();
		String Home_page_title = driver.getTitle();

		System.out.println("messags " + pr.getProperty("HomePageTitle"));
		
		assertEquals(Home_page_title, pr.getProperty("homePageTitle"));
	}
}
